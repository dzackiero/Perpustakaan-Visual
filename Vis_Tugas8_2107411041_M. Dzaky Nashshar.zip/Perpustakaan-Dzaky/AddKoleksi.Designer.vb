﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddKoleksi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TextBoxNama = New System.Windows.Forms.TextBox()
        Me.RichTextBoxDeskripsi = New System.Windows.Forms.RichTextBox()
        Me.TextBoxPenerbit = New System.Windows.Forms.TextBox()
        Me.TextBoxTahunTerbit = New System.Windows.Forms.TextBox()
        Me.TextBoxLokasiRak = New System.Windows.Forms.TextBox()
        Me.TextBoxStock = New System.Windows.Forms.TextBox()
        Me.RadioButtonIndonesia = New System.Windows.Forms.RadioButton()
        Me.GroupBoxBahasa = New System.Windows.Forms.GroupBox()
        Me.RadioButtonInggris = New System.Windows.Forms.RadioButton()
        Me.GroupBoxKategori = New System.Windows.Forms.GroupBox()
        Me.CheckBoxBudaya = New System.Windows.Forms.CheckBox()
        Me.CheckBoxTeknologi = New System.Windows.Forms.CheckBox()
        Me.CheckBoxSosial = New System.Windows.Forms.CheckBox()
        Me.CheckBoxSains = New System.Windows.Forms.CheckBox()
        Me.ComboBoxJenisKoleksi = New System.Windows.Forms.ComboBox()
        Me.DateTimePickerTanggalMasuk = New System.Windows.Forms.DateTimePicker()
        Me.ButtonTambahKoleksi = New System.Windows.Forms.Button()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.PictureBoxKoleksi = New System.Windows.Forms.PictureBox()
        Me.ButtonUploadPhoto = New System.Windows.Forms.Button()
        Me.GroupBoxBahasa.SuspendLayout()
        Me.GroupBoxKategori.SuspendLayout()
        CType(Me.PictureBoxKoleksi, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(132, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(79, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Nama Koleksi"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(132, 46)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 15)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Jenis Koleksi"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(132, 70)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(54, 15)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Deskripsi"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(132, 155)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 15)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Penerbit"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(132, 185)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(71, 15)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Tahun Terbit"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(132, 214)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(62, 15)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "Lokasi Rak"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(132, 271)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(36, 15)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Stock"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(132, 242)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(126, 15)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Tanggal Masuk Koleksi"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(132, 380)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(51, 15)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "Kategori"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(132, 300)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(44, 15)
        Me.Label11.TabIndex = 11
        Me.Label11.Text = "Bahasa"
        '
        'TextBoxNama
        '
        Me.TextBoxNama.Location = New System.Drawing.Point(271, 9)
        Me.TextBoxNama.Name = "TextBoxNama"
        Me.TextBoxNama.Size = New System.Drawing.Size(163, 23)
        Me.TextBoxNama.TabIndex = 12
        '
        'RichTextBoxDeskripsi
        '
        Me.RichTextBoxDeskripsi.Location = New System.Drawing.Point(271, 67)
        Me.RichTextBoxDeskripsi.Name = "RichTextBoxDeskripsi"
        Me.RichTextBoxDeskripsi.Size = New System.Drawing.Size(163, 74)
        Me.RichTextBoxDeskripsi.TabIndex = 14
        Me.RichTextBoxDeskripsi.Text = ""
        '
        'TextBoxPenerbit
        '
        Me.TextBoxPenerbit.Location = New System.Drawing.Point(271, 147)
        Me.TextBoxPenerbit.Name = "TextBoxPenerbit"
        Me.TextBoxPenerbit.Size = New System.Drawing.Size(163, 23)
        Me.TextBoxPenerbit.TabIndex = 15
        '
        'TextBoxTahunTerbit
        '
        Me.TextBoxTahunTerbit.Location = New System.Drawing.Point(271, 177)
        Me.TextBoxTahunTerbit.Name = "TextBoxTahunTerbit"
        Me.TextBoxTahunTerbit.Size = New System.Drawing.Size(163, 23)
        Me.TextBoxTahunTerbit.TabIndex = 16
        '
        'TextBoxLokasiRak
        '
        Me.TextBoxLokasiRak.Location = New System.Drawing.Point(271, 206)
        Me.TextBoxLokasiRak.Name = "TextBoxLokasiRak"
        Me.TextBoxLokasiRak.Size = New System.Drawing.Size(163, 23)
        Me.TextBoxLokasiRak.TabIndex = 17
        '
        'TextBoxStock
        '
        Me.TextBoxStock.Location = New System.Drawing.Point(271, 263)
        Me.TextBoxStock.Name = "TextBoxStock"
        Me.TextBoxStock.Size = New System.Drawing.Size(163, 23)
        Me.TextBoxStock.TabIndex = 19
        '
        'RadioButtonIndonesia
        '
        Me.RadioButtonIndonesia.AutoSize = True
        Me.RadioButtonIndonesia.Location = New System.Drawing.Point(6, 22)
        Me.RadioButtonIndonesia.Name = "RadioButtonIndonesia"
        Me.RadioButtonIndonesia.Size = New System.Drawing.Size(116, 19)
        Me.RadioButtonIndonesia.TabIndex = 21
        Me.RadioButtonIndonesia.TabStop = True
        Me.RadioButtonIndonesia.Text = "Bahasa Indonesia"
        Me.RadioButtonIndonesia.UseVisualStyleBackColor = True
        '
        'GroupBoxBahasa
        '
        Me.GroupBoxBahasa.Controls.Add(Me.RadioButtonInggris)
        Me.GroupBoxBahasa.Controls.Add(Me.RadioButtonIndonesia)
        Me.GroupBoxBahasa.Location = New System.Drawing.Point(271, 292)
        Me.GroupBoxBahasa.Name = "GroupBoxBahasa"
        Me.GroupBoxBahasa.Size = New System.Drawing.Size(163, 76)
        Me.GroupBoxBahasa.TabIndex = 22
        Me.GroupBoxBahasa.TabStop = False
        Me.GroupBoxBahasa.Text = "Bahasa"
        '
        'RadioButtonInggris
        '
        Me.RadioButtonInggris.AutoSize = True
        Me.RadioButtonInggris.Location = New System.Drawing.Point(6, 43)
        Me.RadioButtonInggris.Name = "RadioButtonInggris"
        Me.RadioButtonInggris.Size = New System.Drawing.Size(101, 19)
        Me.RadioButtonInggris.TabIndex = 22
        Me.RadioButtonInggris.TabStop = True
        Me.RadioButtonInggris.Text = "Bahasa Inggris"
        Me.RadioButtonInggris.UseVisualStyleBackColor = True
        '
        'GroupBoxKategori
        '
        Me.GroupBoxKategori.Controls.Add(Me.CheckBoxBudaya)
        Me.GroupBoxKategori.Controls.Add(Me.CheckBoxTeknologi)
        Me.GroupBoxKategori.Controls.Add(Me.CheckBoxSosial)
        Me.GroupBoxKategori.Controls.Add(Me.CheckBoxSains)
        Me.GroupBoxKategori.Location = New System.Drawing.Point(271, 380)
        Me.GroupBoxKategori.Name = "GroupBoxKategori"
        Me.GroupBoxKategori.Size = New System.Drawing.Size(163, 124)
        Me.GroupBoxKategori.TabIndex = 23
        Me.GroupBoxKategori.TabStop = False
        Me.GroupBoxKategori.Text = "Kategori"
        '
        'CheckBoxBudaya
        '
        Me.CheckBoxBudaya.AutoSize = True
        Me.CheckBoxBudaya.Location = New System.Drawing.Point(6, 97)
        Me.CheckBoxBudaya.Name = "CheckBoxBudaya"
        Me.CheckBoxBudaya.Size = New System.Drawing.Size(65, 19)
        Me.CheckBoxBudaya.TabIndex = 3
        Me.CheckBoxBudaya.Text = "Budaya"
        Me.CheckBoxBudaya.UseVisualStyleBackColor = True
        '
        'CheckBoxTeknologi
        '
        Me.CheckBoxTeknologi.AutoSize = True
        Me.CheckBoxTeknologi.Location = New System.Drawing.Point(6, 72)
        Me.CheckBoxTeknologi.Name = "CheckBoxTeknologi"
        Me.CheckBoxTeknologi.Size = New System.Drawing.Size(77, 19)
        Me.CheckBoxTeknologi.TabIndex = 2
        Me.CheckBoxTeknologi.Text = "Teknologi"
        Me.CheckBoxTeknologi.UseVisualStyleBackColor = True
        '
        'CheckBoxSosial
        '
        Me.CheckBoxSosial.AutoSize = True
        Me.CheckBoxSosial.Location = New System.Drawing.Point(6, 47)
        Me.CheckBoxSosial.Name = "CheckBoxSosial"
        Me.CheckBoxSosial.Size = New System.Drawing.Size(56, 19)
        Me.CheckBoxSosial.TabIndex = 1
        Me.CheckBoxSosial.Text = "Sosial"
        Me.CheckBoxSosial.UseVisualStyleBackColor = True
        '
        'CheckBoxSains
        '
        Me.CheckBoxSains.AutoSize = True
        Me.CheckBoxSains.Location = New System.Drawing.Point(6, 22)
        Me.CheckBoxSains.Name = "CheckBoxSains"
        Me.CheckBoxSains.Size = New System.Drawing.Size(53, 19)
        Me.CheckBoxSains.TabIndex = 0
        Me.CheckBoxSains.Text = "Sains"
        Me.CheckBoxSains.UseVisualStyleBackColor = True
        '
        'ComboBoxJenisKoleksi
        '
        Me.ComboBoxJenisKoleksi.FormattingEnabled = True
        Me.ComboBoxJenisKoleksi.Location = New System.Drawing.Point(271, 38)
        Me.ComboBoxJenisKoleksi.Name = "ComboBoxJenisKoleksi"
        Me.ComboBoxJenisKoleksi.Size = New System.Drawing.Size(163, 23)
        Me.ComboBoxJenisKoleksi.TabIndex = 24
        '
        'DateTimePickerTanggalMasuk
        '
        Me.DateTimePickerTanggalMasuk.Location = New System.Drawing.Point(271, 236)
        Me.DateTimePickerTanggalMasuk.Name = "DateTimePickerTanggalMasuk"
        Me.DateTimePickerTanggalMasuk.Size = New System.Drawing.Size(163, 23)
        Me.DateTimePickerTanggalMasuk.TabIndex = 25
        '
        'ButtonTambahKoleksi
        '
        Me.ButtonTambahKoleksi.Location = New System.Drawing.Point(165, 524)
        Me.ButtonTambahKoleksi.Name = "ButtonTambahKoleksi"
        Me.ButtonTambahKoleksi.Size = New System.Drawing.Size(123, 23)
        Me.ButtonTambahKoleksi.TabIndex = 26
        Me.ButtonTambahKoleksi.Text = "Tambah Koleksi"
        Me.ButtonTambahKoleksi.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'PictureBoxKoleksi
        '
        Me.PictureBoxKoleksi.Location = New System.Drawing.Point(12, 17)
        Me.PictureBoxKoleksi.Name = "PictureBoxKoleksi"
        Me.PictureBoxKoleksi.Size = New System.Drawing.Size(100, 110)
        Me.PictureBoxKoleksi.TabIndex = 27
        Me.PictureBoxKoleksi.TabStop = False
        '
        'ButtonUploadPhoto
        '
        Me.ButtonUploadPhoto.Location = New System.Drawing.Point(12, 133)
        Me.ButtonUploadPhoto.Name = "ButtonUploadPhoto"
        Me.ButtonUploadPhoto.Size = New System.Drawing.Size(100, 23)
        Me.ButtonUploadPhoto.TabIndex = 28
        Me.ButtonUploadPhoto.Text = "Upload Photo"
        Me.ButtonUploadPhoto.UseVisualStyleBackColor = True
        '
        'AddKoleksi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(446, 559)
        Me.Controls.Add(Me.ButtonUploadPhoto)
        Me.Controls.Add(Me.PictureBoxKoleksi)
        Me.Controls.Add(Me.ButtonTambahKoleksi)
        Me.Controls.Add(Me.DateTimePickerTanggalMasuk)
        Me.Controls.Add(Me.ComboBoxJenisKoleksi)
        Me.Controls.Add(Me.GroupBoxKategori)
        Me.Controls.Add(Me.GroupBoxBahasa)
        Me.Controls.Add(Me.TextBoxStock)
        Me.Controls.Add(Me.TextBoxLokasiRak)
        Me.Controls.Add(Me.TextBoxTahunTerbit)
        Me.Controls.Add(Me.TextBoxPenerbit)
        Me.Controls.Add(Me.RichTextBoxDeskripsi)
        Me.Controls.Add(Me.TextBoxNama)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "AddKoleksi"
        Me.Text = "Kategori"
        Me.GroupBoxBahasa.ResumeLayout(False)
        Me.GroupBoxBahasa.PerformLayout()
        Me.GroupBoxKategori.ResumeLayout(False)
        Me.GroupBoxKategori.PerformLayout()
        CType(Me.PictureBoxKoleksi, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents TextBoxNama As TextBox
    Friend WithEvents RichTextBoxDeskripsi As RichTextBox
    Friend WithEvents TextBoxPenerbit As TextBox
    Friend WithEvents TextBoxTahunTerbit As TextBox
    Friend WithEvents TextBoxLokasiRak As TextBox
    Friend WithEvents TextBoxStock As TextBox
    Friend WithEvents RadioButtonIndonesia As RadioButton
    Friend WithEvents GroupBoxBahasa As GroupBox
    Friend WithEvents RadioButtonInggris As RadioButton
    Friend WithEvents GroupBoxKategori As GroupBox
    Friend WithEvents CheckBoxBudaya As CheckBox
    Friend WithEvents CheckBoxTeknologi As CheckBox
    Friend WithEvents CheckBoxSosial As CheckBox
    Friend WithEvents CheckBoxSains As CheckBox
    Friend WithEvents ComboBoxJenisKoleksi As ComboBox
    Friend WithEvents DateTimePickerTanggalMasuk As DateTimePicker
    Friend WithEvents ButtonTambahKoleksi As Button
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents PictureBoxKoleksi As PictureBox
    Friend WithEvents ButtonUploadPhoto As Button
End Class
