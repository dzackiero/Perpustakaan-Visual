﻿Class AddKoleksiHelpers

    Public Shared dataPerpus As DataPerpus
End Class
